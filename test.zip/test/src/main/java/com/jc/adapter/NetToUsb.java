package com.jc.adapter;


//接口转换器的抽象实现
public interface NetToUsb {

//    作用：处理请求，网线=》usb
    public void handleRequest();

}
