package com.jc.proxy.proxy_static.demo1;


//租房的抽象业务
public interface Rent {

    public void rent();

}
