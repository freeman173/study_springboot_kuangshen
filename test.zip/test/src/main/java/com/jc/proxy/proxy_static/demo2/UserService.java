package com.jc.proxy.proxy_static.demo2;



//抽象业务
public interface UserService {

    public void add(String name);
    public void delete();
    public void update();
    public void query();
}
