package com.jc.fanshe;

public class Teacher {
    public Teacher() {
    }

    public void sleep(){

        System.out.println("老师也喜欢睡觉！");
    }
}
