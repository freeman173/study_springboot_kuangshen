package com.jc.factory.method;

public class BenChi implements Car {


    @Override
    public void name() {
        System.out.println("我是BenChi");
    }
}
