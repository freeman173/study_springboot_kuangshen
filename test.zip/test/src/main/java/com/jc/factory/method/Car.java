package com.jc.factory.method;

public interface Car {
    void name();
}
