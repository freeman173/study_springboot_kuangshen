package com.jc.factory.method;


/*
工厂方法模式：




 */
public interface CarFactory {

    public Car getCar();
}
