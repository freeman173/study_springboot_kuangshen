package com.jc.factory.simple;

public interface Car {
    void name();
}
