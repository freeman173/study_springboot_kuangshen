package com.jc.factory.method;

public class DaZong implements Car {

    @Override
    public void name() {
        System.out.println("我是DaZong！");
    }
}
