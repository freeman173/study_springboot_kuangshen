package com.jc.abstractFactory.abstracts;


//手机产品的接口
public interface IphoneProduct {

    void start();
    void shutdown();
    void callup();
    void sendMs();

}
